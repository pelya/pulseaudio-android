#define LONG 1
#include "c-strtod.c"
