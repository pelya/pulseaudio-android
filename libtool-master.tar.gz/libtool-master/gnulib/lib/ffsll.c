#define FUNC ffsll
#define TYPE long long int
#define GCC_BUILTIN __builtin_ffsll
#include "ffsl.h"
